﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;

public partial class Pages_Request : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //int loop1, loop2;
        //NameValueCollection coll;

        //// Load Header collection into NameValueCollection object.
        ////coll = Request.Headers;

        //coll = Request.Params;

        //// Put the names of all keys into a string array.
        //String[] arr1 = coll.AllKeys;
        //for (loop1 = 0; loop1 < arr1.Length; loop1++)
        //{
        //    Response.Write("Key: " + arr1[loop1] + "<br>");
        //    // Get all values under this key.
        //    String[] arr2 = coll.GetValues(arr1[loop1]);
        //    for (loop2 = 0; loop2 < arr2.Length; loop2++)
        //    {
        //        Response.Write("Value " + loop2 + ": " + Server.HtmlEncode(arr2[loop2]) + "<br>");
        //    }
        //}

        ////Label1.Text = Request.QueryString["param"];
        //Label1.Text = Request.Params.Get("HTTP_HOST");

        //Response.Write("info\r\nnewline");


        String UserHostAddress = Request.UserHostAddress;
        list.Add("Request.Params[HTTP_HOST]：" + Request.Params.Get("HTTP_HOST"));
        list.Add("Request.Url：" + Request.Url.ToString());
        list.Add("Request.UserHostAddress：" + Request.UserHostAddress);
        list.Add("Request.UserHostName：" + Request.UserHostName);
        list.Add("Request.UserLanguages：" + Request.UserLanguages[0]);
        list.Add("Request.UserAgent：" + Request.UserAgent);
        list.Add("Request.UrlReferrer：" + Request.UrlReferrer);
        list.Add("Request.RequestType：" + Request.RequestType);
        list.Add("Request.Browser.Browser：" + Request.Browser.Browser);
        list.Add("Request.Browser.Version：" + Request.Browser.Version);

        list.Add("Request.ServerVariables[REMOTE_ADDR]：" + Request.ServerVariables["REMOTE_ADDR"]);

        String info = NoteInfo("Request信息页", list);
        Response.Write(info);
        //Label1.Text = Request.Url.ToString();
        //Label1.Text = Request.RawUrl;
        //Label1.Text = Request.Url.DnsSafeHost;
    }


    List<String> list = new List<string>();

    /// <summary>
    /// 页面使用说明信息
    /// </summary>
    private String NoteInfo(String tittle, List<String> list)
    {
        StringBuilder Str = new StringBuilder();
        Str.AppendLine("<!DOCTYPE html>");
        Str.AppendLine("<html lang=\"zh-CN\">");
        Str.AppendLine("");
        Str.AppendLine("<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
        Str.AppendLine("<title>" + tittle + "</title>");
        Str.AppendLine("</head>");
        Str.AppendLine("");
        Str.AppendLine("<body>");
        Str.AppendLine("<div>");
        foreach (String str in list)
        {
            Str.AppendLine("<p>" + str + "</p>");
        }
        Str.AppendLine("</div>");
        Str.AppendLine("</body>");
        Str.AppendLine("");
        Str.AppendLine("</html>");

        return Str.ToString();
    }
}