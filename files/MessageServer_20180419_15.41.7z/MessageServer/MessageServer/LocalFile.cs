﻿using FileExplorer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MessageServer
{
    /// <summary>
    /// 本地文件信息获取、处理类
    /// </summary>
    class LocalFile
    {
        public static string Process(string cmd)
        {
            string data = "";

            try
            {
                string START = "[.FileInfo]";
                if (cmd.StartsWith(START))
                {
                    cmd = cmd.Substring(START.Length).Trim();   // 获取cmd信息

                    if (cmd.Equals("[.DriverInfo]"))            // 磁盘信息
                    {
                        data = (new DriverInfo()).ToJson();
                    }
                    else if (cmd.Equals("[.SystemDirTree]"))    // 目录树信息
                    {
                        data = (new SystemDirTree()).ToJson();
                    }
                    else if (cmd.StartsWith("[.DirInfo]"))      // 指定目录文件信息
                    {
                        string path = cmd.Substring("[.DirInfo]".Length).Trim();
                        bool containsFile = true;
                        if (path.StartsWith("[.DirOnly]"))      // 仅获取目录信息
                        {
                            path = path.Substring("[.DirOnly]".Length).Trim();
                            containsFile = false;
                        }
                        data = (new DirInfo(path, containsFile)).ToJson();    
                    }
                    else if (cmd.StartsWith("[.ProcessStart]")) // Start指定文件
                    {
                        string path = cmd.Substring("[.ProcessStart]".Length).Trim();
                        System.Diagnostics.Process.Start(path); 
                        data = "SUCCESS";
                    }
                    else if (cmd.StartsWith("[.FileCopy]"))     // 文件复制
                    {
                        string path = cmd.Substring("[.FileCopy]".Length).Trim();
                        bool overwrite = false;
                        if (path.StartsWith("[.overwrite]"))
                        {
                            path = path.Substring("[.overwrite]".Length).Trim();
                            overwrite = true;
                        }
                        if (path.Contains("[.:]"))
                        {
                            String[] paths = SplitTwo(path, "[.:]");
                            if(!paths[0].Equals(paths[1])) File.Copy(paths[0], paths[1], overwrite);
                            data = "SUCCESS";
                        }
                    }
                    else if (cmd.StartsWith("[.FileMove]"))     // 文件移动
                    {
                        string path = cmd.Substring("[.FileMove]".Length).Trim();
                        if (path.Contains("[.:]"))
                        {
                            String[] paths = SplitTwo(path, "[.:]");
                            if (!paths[0].Equals(paths[1])) File.Move(paths[0], paths[1]);
                            data = "SUCCESS";
                        }
                    }
                    else if (cmd.StartsWith("[.FileDelete]"))   // 删除文件
                    {
                        string path = cmd.Substring("[.FileDelete]".Length).Trim();
                        File.Delete(path);
                        data = "SUCCESS";
                    }
                    else if (cmd.StartsWith("[.FileCreate]"))   // 创建指定路径名称的文件
                    {
                        string path = cmd.Substring("[.FileCreate]".Length).Trim();
                        if (!File.Exists(path)) File.Create(path);
                        data = "SUCCESS";
                    }
                    else if (cmd.StartsWith("[.FileExists]"))   // 判断指定的文件是否存在
                    {
                        string path = cmd.Substring("[.FileExists]".Length).Trim();
                        data = File.Exists(path) ? "true" : "false";
                    }
                    else if (cmd.StartsWith("[.DirectoryCopy]")) // 复制目录
                    {
                        string path = cmd.Substring("[.DirectoryCopy]".Length).Trim();
                        bool overwrite = false;
                        if (path.StartsWith("[.overwrite]"))
                        {
                            path = path.Substring("[.overwrite]".Length).Trim();
                            overwrite = true;
                        }
                        if (path.Contains("[.:]"))
                        {
                            String[] paths = SplitTwo(path, "[.:]");
                            if (!paths[0].Equals(paths[1])) CopyFolderTo(paths[0], paths[1], overwrite);
                            data = "SUCCESS";
                        }
                    }
                    else if (cmd.StartsWith("[.DirectoryMove]"))     // 移动目录
                    {
                        string path = cmd.Substring("[.DirectoryMove]".Length).Trim();
                        if (path.Contains("[.:]"))
                        {
                            String[] paths = SplitTwo(path, "[.:]");
                            if (!paths[0].Equals(paths[1])) Directory.Move(paths[0], paths[1]);
                            data = "SUCCESS";
                        }
                    }
                    else if (cmd.StartsWith("[.DirectoryDelete]"))     // 文件复制
                    {
                        string path = cmd.Substring("[.DirectoryDelete]".Length).Trim();
                        bool recursive = false;
                        if (path.StartsWith("[.recursive]"))
                        {
                            path = path.Substring("[.recursive]".Length).Trim();
                            recursive = true;
                        }
                        Directory.Delete(path, recursive);
                        data = "SUCCESS";
                    }
                    else if (cmd.StartsWith("[.DirectoryCreate]"))   // 创建指定路径名称的文件
                    {
                        string path = cmd.Substring("[.DirectoryCreate]".Length).Trim();
                        if(!Directory.Exists(path)) Directory.CreateDirectory(path);
                        data = "SUCCESS";
                    }
                    else if (cmd.StartsWith("[.DirectoryExists]"))   // 判断指定的文件是否存在
                    {
                        string path = cmd.Substring("[.DirectoryExists]".Length).Trim();
                        data = Directory.Exists(path) ? "true" : "false";
                    }
                }
            }
            catch (Exception)
            {
            }

            if (data.Equals("")) return "";
            else return "[data]->" + data;
        }

        private static String[] SplitTwo(String data, String sp)
        {
            if(data.Contains(sp))
            {
                int index = data.IndexOf(sp);
                String str1 = data.Substring(0, index);
                String str2 = data.Substring(index + sp.Length);

                return new String[]{str1, str2};
            }
            else return new String[]{data, ""};
        }

        /// <summary>
        /// 从一个目录将其内容复制到另一目录
        /// </summary>
        public static void CopyFolderTo(string dirSource, string dirTarget, bool overwirite)
        {
            // 先获取Source目录下，当前的文件目录信息。在复制前先读取文件和目录信息，避免父目录向子目录复制时出现的无限复制循环，而只执行一次复制
            DirectoryInfo directoryInfo = new DirectoryInfo(dirSource);
            FileInfo[] files = directoryInfo.GetFiles();
            DirectoryInfo[] directoryInfoArray = directoryInfo.GetDirectories();

            //检查目标路径是否存在目的目录
            if (!Directory.Exists(dirTarget)) Directory.CreateDirectory(dirTarget);

            //先来复制所有文件  
            foreach (FileInfo file in files)
            {
                string fileSource = Path.Combine(file.DirectoryName, file.Name);
                string fileTarget = Path.Combine(dirTarget, file.Name);
                file.CopyTo(fileTarget, overwirite);
            }

            //最后复制目录
            foreach (DirectoryInfo dir in directoryInfoArray)
            {
                CopyFolderTo(Path.Combine(dirSource, dir.Name), Path.Combine(dirTarget, dir.Name), overwirite);
            }
        }

    }

}
