﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MessageClient
{
    /// <summary>
    /// 客户端适配器。用于获取客户端数据信息，向客户端发送逻辑处理命令
    /// </summary>
    public class ClientAdapter
    {
        private Client client;
        public ClientAdapter(Object clientObj)
        {
            this.client = clientObj as Client;
            client.setDataPrint(Receive);       // 设置数据接收函数
        }


        #region 数据数据发送与接收

        /// <summary>
        /// 程序等待延迟执行
        /// </summary>
        public void Sleep(long ms)
        {
            long startMs = DateTime.Now.Ticks / 10000;
            while ((DateTime.Now.Ticks / 10000) - startMs < ms)
            {
                Application.DoEvents();
            }
        }

        // 发送数据信息至client
        public String Send(string info)
        {
            if (client == null) return "";

            //if (uploadFileMode) // 上传文件时，不执行其他操作
            //{
            //    if (!info.StartsWith("[.FileWrite]")) return "";
            //}

            isReciveData = false;
            client.Send("[.FileInfo]" + info);
            client.Send("[.FileInfoEnd]");

            while (!isReciveData)
            {
                Sleep(10);
            }

            return receiveData;
        }

        bool isReciveData = false;
        String receiveData = "";
        // 接收到的数据信息
        private void Receive(string info)
        {
            info = info.Substring("[data]->".Length).Trim();
            receiveData = info;
            isReciveData = true;
        }

        #endregion


        //-------------

        #region client端功能接口
        
        /// <summary>
        /// 在client端调用cmd.exe执行
        /// </summary>
        public void RunCmd(String info)
        {
            client.Send("[.RunCmd]" + info);
        }

        /// <summary>
        /// 获取client端的磁盘信息
        /// </summary>
        public DriverInfo getDriverInfo()
        {
            String data = Send("[.DriverInfo]");

            if (data.Equals("")) return null;
            else return DriverInfo.Parse(data);
        }

        /// <summary>
        /// 获取client端的系统目录树
        /// </summary>
        public SystemDirTree getSystemDirTree()
        {
            String data = Send("[.SystemDirTree]");

            if (data.Equals("")) return null;
            else return SystemDirTree.Parse(data);
        }

        /// <summary>
        /// 获取client端的指定目录信息
        /// </summary>
        public DirInfo getDirInfo(String dirPath, bool containsFile = true)
        {
            String data = Send("[.DirInfo]" + (!containsFile ? "[.DirOnly]" : "") + dirPath);

            if (data.Equals("")) return null;
            else return DirInfo.Parse(data);
        }

        /// <summary>
        /// 启动client端的指定文件
        /// </summary>
        public bool ProcessStart(String dirPath)
        {
            String data = Send("[.ProcessStart]" + dirPath);
            return (data.Equals("SUCCESS"));
        }

        /// <summary>
        /// 复制文件到指定路径，overwrite若文件存在是否覆盖
        /// </summary>
        public bool FileCopy(String sourceFile, String targetFile, bool overwrite)
        {
            String data = Send("[.FileCopy]" + (overwrite ? "[.overwrite]" : "") + sourceFile + "[.:]" + targetFile);
            return (data.Equals("SUCCESS"));
        }

        /// <summary>
        /// 文件移动到指定路径
        /// </summary>
        public bool FileMove(String sourceFile, String targetFile)
        {
            String data = Send("[.FileMove]" + sourceFile + "[.:]" + targetFile);
            return (data.Equals("SUCCESS"));
        }

        /// <summary>
        /// 删除指定文件
        /// </summary>
        public bool FileDelete(String dirPath)
        {
            String data = Send("[.FileDelete]" + dirPath);
            return (data.Equals("SUCCESS"));
        }


        /// <summary>
        /// 创建文件
        /// </summary>
        public bool FileCreate(String path)
        {
            String data = Send("[.FileCreate]" + path);
            return (data.Equals("SUCCESS"));
        }

        /// <summary>
        /// 判断文件是否存在
        /// </summary>
        public bool FileExists(String path)
        {
            String data = Send("[.FileExists]" + path);
            return (data.Equals("true"));
        }
        
        /// <summary>
        /// 目录移动到指定路径
        /// </summary>
        public bool DirectoryMove(String sourceFile, String targetFile)
        {
            String data = Send("[.DirectoryMove]" + sourceFile + "[.:]" + targetFile);
            return (data.Equals("SUCCESS"));
        }

        /// <summary>
        /// 复制目录到指定路径，overwrite若文件存在是否覆盖
        /// </summary>
        public bool DirectoryCopy(String sourceFile, String targetFile, bool overwrite)
        {
            String data = Send("[.DirectoryCopy]" + (overwrite ? "[.overwrite]" : "") + sourceFile + "[.:]" + targetFile);
            return (data.Equals("SUCCESS"));
        }

        /// <summary>
        /// 删除指定目录
        /// </summary>
        public bool DirectoryDelete(String dirPath, bool recursive)
        {
            String data = Send("[.DirectoryDelete]" + (recursive ? "[.recursive]" : "") + dirPath);
            return (data.Equals("SUCCESS"));
        }


        /// <summary>
        /// 创建目录
        /// </summary>
        public bool DirectoryCreate(String path)
        {
            String data = Send("[.DirectoryCreate]" + path);
            return (data.Equals("SUCCESS"));
        }


        /// <summary>
        /// 判断目录是否存在
        /// </summary>
        public bool DirectoryExists(String path)
        {
            String data = Send("[.DirectoryExists]" + path);
            return (data.Equals("true"));
        }


        #region 上传文件

        /// <summary>
        /// 将字节数组，写入到指定的文件中
        /// </summary>
        public bool FileWrite(String path, byte[] array, int offset, int count)
        {
            //String arrayData = Encoding.UTF8.GetString(array, 0, count);
            String arrayData = RecodeTool.Bytes2String(array);
            String data = Send("[.FileWrite]" + path + "[.:]" + offset + "[.:]" + count + "[.:]" + arrayData);
            return (data.Equals("SUCCESS"));
        }

        bool uploadFileMode = false;    // 上传文件模式
        /// <summary>
        /// 上传指定的文件
        /// </summary>
        public bool UploadFile(String sourcePath, String targetPath)
        {
            FileStream fs = new FileStream(sourcePath, FileMode.Open);    // 读取方式打开，得到流
            int SIZE = 10 * 8192;               // 缓存
            byte[] datas = new byte[SIZE];      // 要读取的内容会放到这个数组里

            FileInfo info = new FileInfo(sourcePath);

            uploadFileMode = true;
            int count = 0;
            int offset = 0;
            do
            {
                fs.Seek(offset, SeekOrigin.Begin);
                count = fs.Read(datas, 0, SIZE);
                
                bool result = FileWrite(targetPath, datas, offset, count);
                if (!result) return false;

                offset += count;
                Thread.Sleep(20);      // 延时0.02后处理接收到的信息

            } while (offset < info.Length);

            fs.Close();
            FileWrite(targetPath, datas, offset, 0);

            uploadFileMode = false;

            return true;
        }

        #endregion



        #region 下载文件

        /// <summary>
        /// 获取文件大小
        /// </summary>
        public int FileLength(String path)
        {
            String data = Send("[.FileLength]" + path).Trim();
            return Int32.Parse(data);
        }


        /// <summary>
        /// 按指定的偏移量，从指定的文件中读取数据，读取SIZE大小
        /// </summary>
        public int FileRead(String path, byte[] array, int offset, int SIZE)
        {
            //String arrayData = Encoding.UTF8.GetString(array, 0, count);
            String data = Send("[.FileRead]" + path + "[.:]" + offset + "[.:]" + SIZE);

            String[] A = SplitTwo(data, "[.:]");
            int count = Int32.Parse(A[0]);
            if (count > 0)
            {
                byte[] bytes = RecodeTool.String2Bytes(A[1]);
                Array.Copy(bytes, array, count);
            }
            return count;
        }

        /// <summary>
        /// 下载文件sourcePath到本地路径targetPath
        /// </summary>
        public bool DownloadFile(String sourcePath, String targetPath)
        {
            FileStream fs = new FileStream(targetPath, FileMode.OpenOrCreate);    // 读取方式打开，得到流
            int SIZE = 10 * 8192;               // 缓存
            byte[] datas = new byte[SIZE];      // 要读取的内容会放到这个数组里

            int fileLen = FileLength(sourcePath);

            int count = 0;
            int offset = 0;
            do
            {
                count = FileRead(sourcePath, datas, offset, SIZE);

                fs.Seek(offset, SeekOrigin.Begin);
                fs.Write(datas, 0, count);
                fs.Flush();

                offset += count;
                Thread.Sleep(20);      // 延时0.02后处理接收到的信息

            } while (offset < fileLen);

            fs.Close();
            FileRead(sourcePath, datas, offset, 0);

            return true;
        }


        /// <summary>
        /// 将data按首个分隔符sp分割成两个字符串
        /// </summary>
        private static String[] SplitTwo(String data, String sp)
        {
            if (data.Contains(sp))
            {
                int index = data.IndexOf(sp);
                String str1 = data.Substring(0, index);
                String str2 = data.Substring(index + sp.Length);

                return new String[] { str1, str2 };
            }
            else return new String[] { data, "" };
        }

        /// <summary>
        /// 将data按分隔符sp进行分割
        /// </summary>
        private static String[] Split(String data, String sp)
        {
            List<String> A = new List<string>();
            while (data.Contains(sp))
            {
                int index = data.IndexOf(sp);
                String str1 = data.Substring(0, index);
                data = data.Substring(index + sp.Length);

                A.Add(str1);
            }
            A.Add(data);

            return A.ToArray();
        }

        #endregion

        /// <summary>
        /// 判断目录是否存在
        /// </summary>
        public String GetScreen()
        {
            String data = Send("[.GetScreen]");
            return data;
        }

        #endregion



    }
}
