﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MessageClient
{
    /// <summary>
    /// 客户端适配器。用于获取客户端数据信息，向客户端发送逻辑处理命令
    /// </summary>
    public class ClientAdapter
    {
        private Client client;
        public ClientAdapter(Object clientObj)
        {
            this.client = clientObj as Client;
            client.setDataPrint(Receive);       // 设置数据接收函数
        }


        #region 数据数据发送与接收

        /// <summary>
        /// 程序等待延迟执行
        /// </summary>
        public void Sleep(long ms)
        {
            long startMs = DateTime.Now.Ticks / 10000;
            while ((DateTime.Now.Ticks / 10000) - startMs < ms)
            {
                Application.DoEvents();
            }
        }

        // 发送数据信息至client
        public String Send(string info)
        {
            if (client == null) return "";

            isReciveData = false;
            client.Send("[.FileInfo]" + info);
            while (!isReciveData)
            {
                Sleep(200);
            }

            return receiveData;
        }

        bool isReciveData = false;
        String receiveData = "";
        // 接收到的数据信息
        private void Receive(string info)
        {
            info = info.Substring("[data]->".Length).Trim();
            receiveData = info;
            isReciveData = true;
        }

        #endregion


        //-------------


        #region client端功能接口

        /// <summary>
        /// 获取client端的磁盘信息
        /// </summary>
        public DriverInfo getDriverInfo()
        {
            String data = Send("[.DriverInfo]");

            if (data.Equals("")) return null;
            else return DriverInfo.Parse(data);
        }

        /// <summary>
        /// 获取client端的系统目录树
        /// </summary>
        public SystemDirTree getSystemDirTree()
        {
            String data = Send("[.SystemDirTree]");

            if (data.Equals("")) return null;
            else return SystemDirTree.Parse(data);
        }

        /// <summary>
        /// 获取client端的指定目录信息
        /// </summary>
        public DirInfo getDirInfo(String dirPath, bool containsFile = true)
        {
            String data = Send("[.DirInfo]" + (!containsFile ? "[.DirOnly]" : "") + dirPath);

            if (data.Equals("")) return null;
            else return DirInfo.Parse(data);
        }

        /// <summary>
        /// 启动client端的指定文件
        /// </summary>
        public bool ProcessStart(String dirPath)
        {
            String data = Send("[.ProcessStart]" + dirPath);
            return (data.Equals("SUCCESS"));
        }
        
        #endregion

    }
}
