package sci.tool;

/**  
 * SocketCallBack.java: Socket信息回调逻辑
 * -----
 * 2019-6-18 下午5:41:56
 * scimence 
 */
public abstract class SocketCallBack
{	
	public abstract void Print(String info);
}
