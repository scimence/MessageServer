﻿
package sci.demo.androidautofit;

import sci.tool.ActivityComponent;
import android.os.Bundle;
import android.widget.RelativeLayout;


/** MsgPage.java:自适应尺寸信息显示界面示例 ----- 2018-11-1 上午10:07:54 scimence */
public class MsgPage extends ActivityComponent
{
	/** 设置界面显示 */
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("autofit_msg_page");
		
		RelativeLayout lPic = RelativeLayout("auto_msg_page_bg");	// 背景图布局Layout
		setAutofitBackground(lPic, "autofit_msg_pic");				// 为view添加自适应尺寸的图像
		
		setAutofitBackground(RelativeLayout("autofit_msg_page_btn"), "autofit_msg_wait");	// 为按钮添加自适应尺寸的图像
	}
	
	/** 设置View点击响应逻辑 */
	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("auto_msg_page_bg") || viewId.equals("autofit_msg_page_btn"))	// 点击了按钮或者背景图时，关闭界面
		{
			this.finish();
		}
	}
	
}
