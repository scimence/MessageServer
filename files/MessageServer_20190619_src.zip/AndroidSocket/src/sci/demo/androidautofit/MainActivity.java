﻿
package sci.demo.androidautofit;

import sci.tool.ActivityComponent;
import sci.tool.SocketCallBack;
import sci.tool.SocketClient;
import sci.tool.ThreadTool;
import sci.tool.ThreadTool.ThreadPram;
import android.os.Bundle;


/** Android Socket 演示demo主界面 */
public class MainActivity extends ActivityComponent
{
	
	SocketClient client = null;
	
	/** 设置界面显示 */
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("activity_main");
	}
	
	/** 按钮点击响应逻辑 */
	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("btn_connect"))
		{
			if (client == null)
			{
				SocketCallBack print = new SocketCallBack()
				{
					@Override
					public void Print(String info)
					{
						showMsg(info);
					}
				};
				
				String ipString = EditText("editIp").getText().toString();					// 服务器端ip地址如： 10.80.8.201
				int port = Integer.parseInt(EditText("editPort").getText().toString());		// 服务器端的监听端口如： 37280
				
				client = new SocketClient(print, ipString, port);	// 创建客户端Socket操作对象
			}
			
			if (client != null) client.start();						// 连接服务器
		}
		else if (viewId.equals("btn_close"))
		{
			client.disconnect();									// 断开连接
		}
		else if (viewId.equals("btn_send"))
		{
			String data = EditText("editMsg").getText().toString();
			client.Send(data);										// 发送信息
		}
	}
	
	/** 在信息显示区显示信息 */
	private void showMsg(final String msg)
	{
		ThreadTool.RunInMainThread(new ThreadPram()
		{
			@Override
			public void Function()
			{
				String content = TextView("textMSG").getText().toString();
				TextView("textMSG").setText(msg + "\r\n" + content);
				
				// ScrollView("msg_scroll").fullScroll(ScrollView.FOCUS_DOWN);
			}
		});
	}
}
