﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MessageClient
{
    public partial class ScreenForm : Form
    {
        ClientAdapter adapter;

        public bool isRemoteMode = false;
        public ScreenForm(Object clientObj = null)
        {
            InitializeComponent();

            if (clientObj != null)
            {
                isRemoteMode = true;
                adapter = new ClientAdapter(clientObj as Client);
            }
        }

        /// <summary>
        /// 获取client端截屏
        /// </summary>
        public Image GetScreen()
        {
            String data = adapter.GetScreen();
            Image screen = RecodeTool.String2Image(data);
            return screen;
        }

        private void showScreen()
        {
            pictureBox_screen.Image = GetScreen();
        }

        private void timer_refresh_Tick(object sender, EventArgs e)
        {
            showScreen();
        }
    }
}
