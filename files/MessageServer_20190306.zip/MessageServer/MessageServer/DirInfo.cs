﻿using MessageServer;
using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace FileExplorer
{
    /// <summary>
    /// 系统Icon
    /// 1、Get()  获取指定索引对应的系统icon 
    /// 2、Save() 保存所有系统图像
    /// 3、Show() 显示所有系统Icon图像
    /// </summary>
    public partial class SystemIcon : Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // SystemIcon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 389);
            this.Name = "SystemIcon";
            this.Text = "FormIcon";
            this.ResumeLayout(false);

        }

        #endregion


        public SystemIcon()
        {
            InitializeComponent();

            Show(this);
            Save();
        }

        /// <summary>
        /// 在form上显示所有系统icon图像
        /// </summary>
        public static void Show(Form form)
        {
            LoadSystemIcon();

            FlowLayoutPanel flowLayout = new FlowLayoutPanel();
            flowLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            flowLayout.AutoScroll = true;

            for (int i = 0; i < SystemIconList.Count; i++)
            {
                PictureBox pic = new PictureBox();
                pic.Size = new System.Drawing.Size(32, 32);
                flowLayout.Controls.Add(pic);

                Bitmap p = SystemIconList[i].ToBitmap();
                pic.Image = p;
            }
            form.Controls.Add(flowLayout);
        }

        /// <summary>
        /// 保存所有系统图像
        /// </summary>
        public static void Save()
        {
            LoadSystemIcon();

            for (int i = 0; i < SystemIconList.Count; i++)
            {
                Bitmap p = SystemIconList[i].ToBitmap();

                // 保存图像
                string path = AppDomain.CurrentDomain.BaseDirectory + "系统图标\\";
                string filepath = path + (i + ".png");
                if (!Directory.Exists(path)) Directory.CreateDirectory(path);
                if (!File.Exists(filepath)) p.Save(filepath);
            }
        }



        /// <summary>
        /// 获取指定索引对应的系统icon；
        /// 
        /// 文件夹：SystemIcon.Get(3)、
        /// 本地磁盘：SystemIcon.Get(8)、
        /// 计算机：SystemIcon.Get(15)、
        /// 桌面：SystemIcon.Get(34)
        /// </summary>
        public static Icon Get(int index)
        {
            LoadSystemIcon();
            return index < SystemIconList.Count ? SystemIconList[index] : null;
        }


        private static List<Icon> SystemIconList = new List<Icon>(); // 记录系统图标

        //[DllImport("user32.dll", CharSet = CharSet.Auto)]
        //private static extern bool MessageBeep(uint type);

        [DllImport("Shell32.dll")]
        public extern static int ExtractIconEx(string libName, int iconIndex, IntPtr[] largeIcon, IntPtr[] smallIcon, int nIcons);

        private static IntPtr[] largeIcon;
        private static IntPtr[] smallIcon;

        /// <summary>
        /// 获取所有系统icon图像
        /// </summary>
        private static void LoadSystemIcon()
        {
            if (SystemIconList.Count > 0) return;

            largeIcon = new IntPtr[1000];
            smallIcon = new IntPtr[1000];

            ExtractIconEx("shell32.dll", 0, largeIcon, smallIcon, 1000);

            SystemIconList.Clear();
            for (int i = 0; i < largeIcon.Length; i++)
            {
                try
                {
                    Icon ic = Icon.FromHandle(largeIcon[i]);
                    SystemIconList.Add(ic);
                }
                catch (Exception ex)
                {
                    break;
                }
            }
        }
    }

    /// <summary>
    /// 数据类型转换工具类，文件与byte数组互转、Image与byte数组互转、byte数组与String互转、Icon与Image互转、Icon与String互转、Image与String互转、Image与Bitmap互转
    /// </summary>
    public class RecodeTool
    {
        # region 文件与byte数组互转

        /// <summary>
        /// 将文件转换为byte数组
        /// </summary>
        /// <param name="path">文件地址</param>
        /// <returns>转换后的byte数组</returns>
        public static byte[] File2Bytes(string path)
        {
            if (!File.Exists(path)) return new byte[0];

            FileInfo fi = new FileInfo(path);
            byte[] buff = new byte[fi.Length];

            FileStream fs = fi.OpenRead();
            fs.Read(buff, 0, Convert.ToInt32(fs.Length));
            fs.Close();

            return buff;
        }

        /// <summary>
        /// 将byte数组转换为文件并保存到指定地址
        /// </summary>
        /// <param name="buff">byte数组</param>
        /// <param name="savepath">保存地址</param>
        public static void Bytes2File(byte[] buff, string savepath)
        {
            if (File.Exists(savepath)) File.Delete(savepath);

            FileStream fs = new FileStream(savepath, FileMode.CreateNew);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write(buff, 0, buff.Length);
            bw.Close();
            fs.Close();
        }

        # endregion


        # region Image与byte数组互转

        /// <summary>
        /// 将Image转化为byte数组
        /// </summary>
        public static byte[] Image2Bytes(Image image, ImageFormat imageFormat = null)
        {
            if (imageFormat == null) imageFormat = ImageFormat.Png;

            System.IO.MemoryStream stream = new System.IO.MemoryStream();
            image.Save(stream, imageFormat);
            byte[] bytes = stream.ToArray();

            return bytes;
        }

        /// <summary>
        /// 从byte数组创建Image
        /// </summary>
        public static Image Bytes2Image(byte[] bytes)
        {
            System.IO.MemoryStream stream = new System.IO.MemoryStream();
            stream.Write(bytes, 0, bytes.Length);
            Image image = Image.FromStream(stream);

            return image;
        }

        /// <summary>
        /// 将Image转化为byte数组,使用缓存文件中转
        /// </summary>
        public static byte[] Image2Bytes_tmpFile(Image image, ImageFormat imageFormat = null)
        {
            if (imageFormat == null) imageFormat = ImageFormat.Jpeg;
            String tmpFilePath = AppDomain.CurrentDomain.BaseDirectory + DateTime.Now.Ticks + ".stream";
            image.Save(tmpFilePath, imageFormat);   // 保存图像到文件

            byte[] bytes = File2Bytes(tmpFilePath); // 从文件中获取字节数组
            if (File.Exists(tmpFilePath)) File.Delete(tmpFilePath); //删除文件

            return bytes;
        }

        # endregion


        # region byte数组与String互转

        /// <summary>
        /// 将byte数组，转化为字符串形式（每个字节转化为两个字母）
        /// </summary>
        public static string Bytes2String(byte[] B)
        {
            StringBuilder Str = new StringBuilder();
            foreach (byte b in B)
            {
                string tmp = "" + (char)('a' + (b / 16)) + (char)('a' + (b % 16));
                Str.Append(tmp);
            }
            return Str.ToString();
        }

        /// <summary>
        /// 将字母字符串还原为byte数组(需与Bytes2String配对使用）
        /// </summary>
        public static byte[] String2Bytes(string data)
        {
            byte[] B = new byte[data.Length / 2];
            char[] C = data.ToCharArray();

            for (int i = 0; i < C.Length; i += 2)
            {
                byte b = (byte)((C[i] - 'a') * 16 + (C[i + 1] - 'a'));
                B[i / 2] = b;
            }

            return B;
        }

        # endregion


        # region Icon与Image互转

        /// <summary>
        /// Icon转化为Image
        /// </summary>
        public static Image Icon2Image(Icon icon)
        {
            Bitmap bitmap = icon.ToBitmap();
            return bitmap;
        }

        /// <summary>
        /// Image转化为Icon
        /// </summary>
        public static Icon Image2Icon(Image image)
        {
            Bitmap bitmap = (Bitmap)image;
            IntPtr ptr = bitmap.GetHicon();
            Icon icon = Icon.FromHandle(ptr);
            return icon;
        }

        # endregion


        # region Icon与String互转

        /// <summary>
        /// Icon转化为字符串
        /// </summary>
        public static string Icon2String(Icon icon)
        {
            Bitmap bitmap = icon.ToBitmap();
            byte[] bytes = Image2Bytes(bitmap);
            String Str = Bytes2String(bytes);
            return Str;
        }

        /// <summary>
        /// String转化为Icon
        /// </summary>
        public static Icon String2Icon(string iconStr)
        {
            byte[] bytes = String2Bytes(iconStr);
            Bitmap bitmap = (Bitmap)Bytes2Image(bytes);
            Icon icon = Icon.FromHandle(bitmap.GetHicon());
            return icon;
        }

        # endregion


        # region Image与String互转

        /// <summary>
        /// Image转化为字符串
        /// </summary>
        public static string Image2String(Image image)
        {
            byte[] bytes = Image2Bytes(image);
            String Str = Bytes2String(bytes);
            return Str;
        }

        /// <summary>
        /// String转化为Image
        /// </summary>
        public static Image String2Image(string imageStr)
        {
            byte[] bytes = String2Bytes(imageStr);
            Image image = Bytes2Image(bytes);
            return image;
        }

        # endregion


        # region Image与Bitmap互转

        /// <summary>
        /// Image转Bitmap
        /// </summary>
        public static Bitmap Image2Bitmap(Image image)
        {
            return (Bitmap)image;
        }

        /// <summary>
        /// Bitmap转Image
        /// </summary>
        public static Image Bitmap2Image(Bitmap bitmap)
        {
            return bitmap;
        }

        # endregion

    }

    /// <summary>
    /// 文件信息工具类
    /// </summary>
    public class FileInfoTool
    {
        /// <summary>
        /// 获取文件FilePath对应的Icon
        /// </summary>
        public static Icon getIcon2(string FilePath)
        {
            return Icon.ExtractAssociatedIcon(FilePath);
        }

        /// <summary>
        /// 转化long为文件大小字符串形式
        /// </summary>
        public static string ToSizeStr(long FileLength)
        {
            string[] UNIT = { "B", "KB", "MB", "GB", "TB" };
            int i = 0;

            double len = FileLength;
            while (len > 1024)
            {
                len = Math.Round((len / 1024.0), 2);
                i++;
                if (i == UNIT.Length - 1) break;
            }

            return len + " " + UNIT[i];
        }

        /// <summary>
        /// 获取文件扩展名对应的描述信息
        /// </summary>
        public static string GetDescription(string extension)
        {
            string description = "";

            //从注册表中读取扩展名相应的子键
            RegistryKey extsubkey = Registry.ClassesRoot.OpenSubKey(extension);
            if (extsubkey == null)  //没有找到，那就是这种类型
            {
                description = extension.ToUpper().Substring(1) + "文件";
                return description;
            }

            //取出扩展名对应的文件类型名称  
            string extdefaultvalue = extsubkey.GetValue(null) as string;
            if (extdefaultvalue == null) return description;

            //扩展名类型是可执行文件
            if (extdefaultvalue.Equals("exefile", StringComparison.InvariantCultureIgnoreCase))
            {
                //从注册表中读取文件类型名称的相应子键  
                RegistryKey exefilesubkey = Registry.ClassesRoot.OpenSubKey(extdefaultvalue);
                if (exefilesubkey != null)  //如果不为空
                {
                    string exefiledescription = exefilesubkey.GetValue(null) as string;   //得到exefile描述字符串  
                    if (exefiledescription != null)
                    {
                        description = exefiledescription;
                    }
                }
                return description;
            }

            //从注册表中读取文件类型名称的相应子键  
            RegistryKey typesubkey = Registry.ClassesRoot.OpenSubKey(extdefaultvalue);
            if (typesubkey == null) return description;

            //得到类型描述字符串  
            string typedescription = typesubkey.GetValue(null) as string;
            if (typedescription != null) description = typedescription;

            return description;
        }
    }

    /// <summary>
    /// 文件浏览器listView项数据
    /// </summary>
    public class ListIteam
    {
        public string name = "", type = "", iteam3 = "", iteam4 = "";   // 名称、类型、日期(总大小)、大小(可用空间)
        public int icon = -1;

        public ListIteam(){}


        //将当前对象的数据，转化为Json串
        public String ToJson()
        {
            return JsonConvert.SerializeObject(this);
        }

        //从Json串创建对象  
        public ListIteam Parse(string JsonStr)
        {
            return JsonConvert.DeserializeObject<ListIteam>(JsonStr);
        }

        // 数组的反序列化，返回对象数组
        public static List<ListIteam> Iteams(string JsonStr)
        {
            List<ListIteam> iteams = JsonConvert.DeserializeObject<List<ListIteam>>(JsonStr);
            return iteams;
        }

        //---------------

        // 从DirectoryInfo获取信息
        public ListIteam(DirectoryInfo dir)
        {
            name = dir.Name;
            type = "文件夹";
            iteam3 = dir.LastWriteTime.ToString("yyyy/MM/dd HH:mm:ss");
            iteam4 = "";
        }

        // 从FileInfo获取信息
        public ListIteam(FileInfo file)
        {
            name = file.Name;
            type = FileInfoTool.GetDescription(file.Extension);
            iteam3 = file.LastWriteTime.ToString("yyyy/MM/dd HH:mm:ss");
            iteam4 = FileInfoTool.ToSizeStr(file.Length);
        }

        // 从DriveInfo获取信息
        public ListIteam(DriveInfo driver)
        {
            name = driver.Name;
            type = TypeName(driver.DriveType);
            try
            {
                iteam3 = FileInfoTool.ToSizeStr(driver.TotalSize);      // 总大小
                iteam4 = FileInfoTool.ToSizeStr(driver.TotalFreeSpace); // 可用空间
            }
            catch (Exception ex) 
            {
                iteam3 = "未知";
                iteam4 = "未知";
            }
        }

        private String TypeName(DriveType type)
        {
            if (type == DriveType.CDRom) return "光盘设备";
            else if (type == DriveType.Fixed) return "本地磁盘";
            else if (type == DriveType.Network) return "网络磁盘";
            else if (type == DriveType.NoRootDirectory) return "无根目录磁盘";
            else if (type == DriveType.Ram) return "RAM磁盘";
            else if (type == DriveType.Removable) return "可移动磁盘";
            else /*if (type == DriveType.Unknown)*/ return "未知类型磁盘";
        }

        /// <summary>
        /// 从当前数据信息创建listView项
        /// </summary>
        public ListViewItem CreatListViewIteam()
        {
            ListViewItem listIteam = new ListViewItem();
            listIteam.Text = name;

            listIteam.SubItems.Add(type);
            listIteam.SubItems.Add(iteam3);
            listIteam.SubItems.Add(iteam4);

            listIteam.ImageIndex = icon;

            return listIteam;
        }

        /// <summary>
        /// 从当前数据信息创建TreeNode
        /// </summary>
        public TreeNode CreateTreeNode()
        {
            TreeNode node = new TreeNode();
            node.Name = name;
            node.Text = name;

            return node;
        }
    }


    /// <summary>
    /// 记录文件名->图像数据信息
    /// </summary>
    public class IconData
    {
        public Dictionary<String, int> NameIndex = new Dictionary<string, int>();   // 记录名称与图像的映射信息
        public List<String> Datas = new List<string>();                             // 保存图像的数据信息

        public IconData()
        {
            //AddIcon("文件夹", SystemIcon.Get(3));
            //AddIcon("本地磁盘", SystemIcon.Get(8));
            //AddIcon("计算机", SystemIcon.Get(15));
            //AddIcon("桌面", SystemIcon.Get(34));
        }

        //将当前对象的数据，转化为Json串
        public String ToJson()
        {
            return JsonConvert.SerializeObject(this);
        }

        //从Json串创建对象  
        public IconData Parse(string JsonStr)
        {
            return JsonConvert.DeserializeObject<IconData>(JsonStr);
        }

        // 数组的反序列化，返回对象数组
        public static List<IconData> Iteams(string JsonStr)
        {
            List<IconData> iteams = JsonConvert.DeserializeObject<List<IconData>>(JsonStr);
            return iteams;
        }

        // --------

        /// <summary>
        /// 记录Name、icon信息到当前对象
        /// </summary>
        public void AddIcon(String Name, Icon icon)
        {
            if (!NameIndex.ContainsKey(Name))
            {
                String iconData = RecodeTool.Icon2String(icon);     // 图像转化为字符串形式
                if (!Datas.Contains(iconData)) Datas.Add(iconData); // 在图像数据集中,记录当前图像信息

                int imageIndex = Datas.IndexOf(iconData);           // 获取图像对应的数据索引信息
                NameIndex.Add(Name, imageIndex);                    // 记录名称索引信息
            }
        }

        /// <summary>
        /// 获取当前对象中保存的所有Icon信息为ImageList
        /// </summary>
        public ImageList getImageList()
        {
            ImageList imageList = new ImageList();
            imageList.ColorDepth = ColorDepth.Depth32Bit;
            imageList.ImageSize = new Size(24, 24);

            foreach (String imageData in Datas)                 // 获取所有icon图像数据
            {
                Icon icon = RecodeTool.String2Icon(imageData);  // 转化为对应的图像
                imageList.Images.Add(icon);                     // 添加图像至list
            }

            return imageList;
        }

    }

    /// <summary>
    /// 文件目录信息
    /// 
    /// 1、获取文件目录信息：DirInfo info = new DirInfo(FullName);
    /// 2、转化为字符串形式：String data = info.ToJson();
    /// 3、在listView中显示：info.ShowIn(listView1);
    /// </summary>
    public class DirInfo
    {
        public String Dir = "";                                 // 当前目录路径
        public List<ListIteam> subDirs = new List<ListIteam>(); // 目录下的文件夹信息
        public List<ListIteam> subFiles = new List<ListIteam>();// 目录下的文件信息

        public IconData iconData = new IconData();              // 文件目录相关的所有Icon图像信息
        public bool containsFile = true;                        // 是否包含文件信息

        //public ImageList imageList;

        public DirInfo() { }

        //将当前对象的数据，转化为Json串
        public String ToJson()
        {
            return JsonConvert.SerializeObject(this);
        }

        //从Json串创建对象  
        public static DirInfo Parse(string JsonStr)
        {
            try
            {
                return JsonConvert.DeserializeObject<DirInfo>(JsonStr);
            }
            catch (Exception)
            {
                return null;
            }
        }

        // 数组的反序列化，返回对象数组
        public static List<DirInfo> Iteams(string JsonStr)
        {
            List<DirInfo> iteams = JsonConvert.DeserializeObject<List<DirInfo>>(JsonStr);
            return iteams;
        }

        //---------------

        /// <summary>
        /// 从指定的目录创建DirInfo, 如 D:\test； 
        /// containsFile标识是否包含文件信息；
        /// </summary>
        public DirInfo(String DirPath, bool containsFile = true)
        {
            this.containsFile = containsFile;
            LoadDirInfo(DirPath);
        }

        /// <summary>
        /// 从指定的目录载入文件信息, 如 D:\test
        /// </summary>
        public void LoadDirInfo(String DirPath)
        {
            Dir = DirPath;
            subDirs.Clear();
            subFiles.Clear();
            iconData = new IconData();

            DirectoryInfo root = new DirectoryInfo(DirPath);

            try
            {
                // 添加文件夹信息
                Icon folderIcon = SystemIcon.Get(3);
                foreach (DirectoryInfo dirInfo in root.GetDirectories())
                {

                    iconData.AddIcon("文件夹", folderIcon); // 添加文件夹Icon信息

                    ListIteam iteam = new ListIteam(dirInfo);
                    iteam.icon = iconData.NameIndex["文件夹"];

                    subDirs.Add(iteam);

                }
            }
            catch (Exception ex) { }

            if (!containsFile) return;  // 若不需要文件信息，则不解析

            try
            {
                // 添加文件信息
                foreach (FileInfo fileInfo in root.GetFiles())
                {
                    Icon icon = FileInfoTool.getIcon2(fileInfo.FullName);   // 获取文件对应的icon图像
                    iconData.AddIcon(fileInfo.Name, icon);              // (按文件名)记录图像

                    ListIteam iteam = new ListIteam(fileInfo);
                    iteam.icon = iconData.NameIndex[fileInfo.Name];     // 获取文件名对应的图像索引

                    subFiles.Add(iteam);
                }
            }
            catch (Exception ex) { }

        }

        /// <summary>
        /// 在listView中显示目录中的文件信息
        /// </summary>
        public void ShowIn(ListView listView)
        {
            listView.View = View.Details;
            listView.AllowColumnReorder = true;
            listView.Columns.Clear();
            listView.Items.Clear();

            ImageList imageList = iconData.getImageList();  // 获取Icon信息

            listView.LargeImageList = imageList;
            listView.SmallImageList = imageList;

            listView.Columns.Add("Name", "名称", 270);
            listView.Columns.Add("Type", "类型", 120);
            listView.Columns.Add("Date", "修改日期", 140);
            listView.Columns.Add("Space", "文件大小", 80);
            listView.Columns["Space"].TextAlign = HorizontalAlignment.Right; //文件大小信息右对齐

            // 生成列表项
            List<ListViewItem> list = new List<ListViewItem>();

            String SP = (Dir.EndsWith("\\") ? "" : "\\");
            foreach (ListIteam iteam in subDirs)
            {
                ListViewItem listIteam = iteam.CreatListViewIteam();
                listIteam.Tag = "Dir:" + Dir + SP + iteam.name;
                list.Add(listIteam);
            }
            foreach (ListIteam iteam in subFiles)
            {
                ListViewItem listIteam = iteam.CreatListViewIteam();
                listIteam.Tag = "File:" + Dir + SP + iteam.name;
                list.Add(listIteam);
            }
            
            // 在listView中显示
            listView.Items.AddRange(list.ToArray());
        }

        /// <summary>
        /// 在treeNode子节点显示目录中的文件信息
        /// </summary>
        public void ShowIn(/*SystemDirTree dirTree, */ TreeNode treeNode)
        {
            if (treeNode.Tag == null) treeNode.Tag = "Dir:" + Dir;
            treeNode.Nodes.Clear();

            String SP = (Dir.EndsWith("\\") ? "" : "\\");
            foreach (ListIteam iteam in subDirs)
            {
                TreeNode node = iteam.CreateTreeNode();
                node.Tag = "Dir:" + Dir + SP + iteam.name;
                node.Text = iteam.name;

                //string StrIcon = iconData.Datas[iteam.icon];    // 获取icon
                //int index = dirTree.AddIcon(StrIcon);           // 添加icon

                int index = 4;
                node.ImageIndex = index;
                node.SelectedImageIndex = index;

                treeNode.Nodes.Add(node);
            }

            //foreach (ListIteam iteam in subFiles)
            //{
            //    TreeNode node = iteam.CreateTreeNode();
            //    node.Tag = "File:" + Dir + SP + iteam.name;
            //    node.Text = iteam.name;

            //    string StrIcon = iconData.Datas[iteam.icon];    // 获取icon
            //    int index = dirTree.AddIcon(StrIcon);           // 添加icon

            //    node.ImageIndex = index;
            //    node.SelectedImageIndex = index;

            //    treeNode.Nodes.Add(node);
            //}
        }

    }

    /// <summary>
    /// 系统磁盘信息
    /// 
    /// 1、获取本地磁盘信息：DriverInfo driver = new DriverInfo();
    /// 2、转化为字符串形式：string data = driver.ToJson();
    /// 3、在listView中显示：driver.ShowIn(listView1);
    /// </summary>
    public class DriverInfo
    {
        public List<ListIteam> drivers = new List<ListIteam>(); // 目录下的文件夹信息
        public IconData iconData = new IconData();              // 文件目录相关的所有Icon图像信息


        // 获取本地磁盘信息
        public DriverInfo(bool isLocalDir = true) 
        {
            if (isLocalDir)
            {
                foreach (DriveInfo driver in DriveInfo.GetDrives())
                {
                    ListIteam iteam = new ListIteam(driver);

                    // 获取磁盘类型对应的icon信息
                    if (!iconData.NameIndex.ContainsKey(iteam.type))
                    {
                        Icon icon = getIcon(iteam.type);
                        iconData.AddIcon(iteam.type, icon);
                    }
                    iteam.icon = iconData.NameIndex[iteam.type];

                    drivers.Add(iteam);
                }
            }
        }

        private Icon getIcon(String type)
        {
            Icon icon;
            // 添加磁盘icon
            if (type == "光盘设备") icon = SystemIcon.Get(177);           // 添加本地磁盘Icon信息
            else if (type == "本地磁盘") icon = SystemIcon.Get(79);
            else if (type == "网络磁盘") icon = SystemIcon.Get(273);
            else if (type == "RAM磁盘") icon = SystemIcon.Get(194);
            else if (type == "可移动磁盘") icon = SystemIcon.Get(258);
            else if (type == "无根目录磁盘") icon = SystemIcon.Get(10);
            else /*if (type == "未知类型磁盘")*/ icon = SystemIcon.Get(53);

            return icon;
        }

        //将当前对象的数据，转化为Json串
        public String ToJson()
        {
            return JsonConvert.SerializeObject(this);
        }


        //从Json串创建对象  
        public static DriverInfo Parse(string JsonStr)
        {
            try
            {
                return JsonConvert.DeserializeObject<DriverInfo>(JsonStr);
            }
            catch (Exception)
            {
                return null;
            }
        }

        // 数组的反序列化，返回对象数组
        public static List<DriverInfo> Iteams(string JsonStr)
        {
            List<DriverInfo> iteams = JsonConvert.DeserializeObject<List<DriverInfo>>(JsonStr);
            return iteams;
        }

        //---------------

        /// <summary>
        /// 在listView中显示目录中的文件信息
        /// </summary>
        public void ShowIn(ListView listView)
        {
            listView.View = View.Details;
            listView.AllowColumnReorder = true;
            listView.Columns.Clear();
            listView.Items.Clear();

            ImageList imageList = iconData.getImageList();  // 获取Icon信息

            listView.LargeImageList = imageList;
            listView.SmallImageList = imageList;

            listView.Columns.Add("Name", "名称", 80);
            listView.Columns.Add("Type", "类型", 80);
            listView.Columns.Add("TotalSpace", "总大小", 100);
            listView.Columns.Add("FreeSpace", "可用空间", 100);

            listView.Columns["TotalSpace"].TextAlign = HorizontalAlignment.Right;   //文件大小信息右对齐
            listView.Columns["FreeSpace"].TextAlign = HorizontalAlignment.Right;    //文件大小信息右对齐

            // 生成列表项
            List<ListViewItem> list = new List<ListViewItem>();

            foreach (ListIteam iteam in drivers)
            {
                ListViewItem listIteam = iteam.CreatListViewIteam();
                listIteam.Tag = "Dir:" + iteam.name;
                list.Add(listIteam);
            }

            // 在listView中显示
            listView.Items.AddRange(list.ToArray());
        }

        /// <summary>
        /// 在TreeView指定节点中显示目录中的文件信息
        /// </summary>
        public void ShowIn(SystemDirTree dirTree, TreeNode treeNode)
        {
            if (treeNode.Tag == null) treeNode.Tag = "Driver:" + "我的电脑";
            treeNode.Nodes.Clear();

            foreach (ListIteam iteam in drivers)
            {
                TreeNode node = iteam.CreateTreeNode();
                node.Tag = "Dir:" + iteam.name;
                node.Text = iteam.name;

                string StrIcon = iconData.Datas[iteam.icon];    // 获取icon
                int index = dirTree.AddIcon(StrIcon);           // 添加icon

                node.ImageIndex = index;
                node.SelectedImageIndex = index;

                treeNode.Nodes.Add(node);
            }
        }
    }

    /// <summary>
    /// 系统目录树
    /// new SystemDirTree().ShowIn(treeView1);
    /// </summary>
    public class SystemDirTree
    {
        public IconData iconData = new IconData();              // 文件目录相关的所有Icon图像信息
        public DriverInfo driverInfo;                              // 系统目录信息

        // 系统目录路径信息
        public DirInfo desktopDir;      // 桌面
        public DirInfo docDir;          // 文档
        public DirInfo recentDir;       // 最近访问


        //将当前对象的数据，转化为Json串
        public String ToJson()
        {
            return JsonConvert.SerializeObject(this);
        }

        //从Json串创建对象  
        public static SystemDirTree Parse(string JsonStr)
        {
            try
            {
                return JsonConvert.DeserializeObject<SystemDirTree>(JsonStr);
            }
            catch (Exception)
            {
                return null;
            }
        }

        // 数组的反序列化，返回对象数组
        public static List<SystemDirTree> Iteams(string JsonStr)
        {
            List<SystemDirTree> iteams = JsonConvert.DeserializeObject<List<SystemDirTree>>(JsonStr);
            return iteams;
        }

        //---------------


        /// <summary>
        /// 向当前对象中添加icon数据，返回icon索引值
        /// </summary>
        public int AddIcon(string StrIcon)
        {
            if (!iconData.Datas.Contains(StrIcon)) iconData.Datas.Add(StrIcon);
            return iconData.Datas.IndexOf(StrIcon);
        }

        public SystemDirTree(bool isLocalDir = true)
        {
            if (isLocalDir)
            {
                iconData.AddIcon("桌面", SystemIcon.Get(34));
                iconData.AddIcon("文档", SystemIcon.Get(158));
                iconData.AddIcon("计算机", SystemIcon.Get(15));
                iconData.AddIcon("最近使用", SystemIcon.Get(213));
                iconData.AddIcon("文件夹", SystemIcon.Get(3));

                driverInfo = new DriverInfo();

                desktopDir = new DirInfo(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory));
                docDir = new DirInfo(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments));
                recentDir = new DirInfo(Environment.GetFolderPath(Environment.SpecialFolder.Recent));
            }
        }

        [JsonIgnore]
        TreeNode desktop = new TreeNode();

        [JsonIgnore]
        TreeNode document = new TreeNode();

        [JsonIgnore]
        TreeNode computer = new TreeNode();

        [JsonIgnore]
        TreeNode recent = new TreeNode();

        private void InitView(TreeView tree)
        {
            desktop.Text = "桌面";
            document.Text = "文档";
            computer.Text = "计算机";
            recent.Text = "最近使用";

            desktop.SelectedImageIndex = desktop.ImageIndex = iconData.NameIndex[desktop.Text];
            document.SelectedImageIndex = document.ImageIndex = iconData.NameIndex[document.Text];
            computer.SelectedImageIndex = computer.ImageIndex = iconData.NameIndex[computer.Text];
            recent.SelectedImageIndex = recent.ImageIndex = iconData.NameIndex[recent.Text];

            tree.ShowLines = false;
            tree.Nodes.Clear();
            tree.Nodes.Add(desktop);
            tree.Nodes.Add(document);
            tree.Nodes.Add(computer);
            tree.Nodes.Add(recent);
            tree.ImageList = iconData.getImageList();
        }

        [JsonIgnore]
        ServerAdapter adapter;
        // 在TreeView中显示系统目录树
        public void ShowIn(TreeView tree, ServerAdapter adapter = null)
        {
            InitView(tree);

            driverInfo.ShowIn(this, computer);             // 在computer节点显示本地磁盘信息

            desktopDir.ShowIn(desktop);         // destop显示桌面
            docDir.ShowIn(document);            // 显示文档
            recentDir.ShowIn(recent);           // 显示最近访问

            tree.ImageList = iconData.getImageList();   // 更新图标信息

            this.adapter = adapter;

            // treeView事件
            if (adapter == null) tree.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.TreeView_AfterExpand);
            else tree.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.TreeView_AfterExpand);
        }


        # region TreeView事件逻辑

        /// <summary>
        /// TreeView节点展开时，载入其下的子节点信息
        /// </summary>
        private void TreeView_AfterExpand(object sender, TreeViewEventArgs e)
        {
            reloadSubNode(e.Node);
        }

        /// <summary>
        /// 重载node节点下的子节点信息
        /// </summary>
        private void reloadSubNode(TreeNode node)
        {
            if (node == null) return;
            foreach (TreeNode n in node.Nodes)
            {
                loadNodeInfo(n);
            }
        }

        /// <summary>
        /// 载入node节点下的目录信息
        /// </summary>
        private void loadNodeInfo(TreeNode node)
        {
            if (node == null) return;
            String tag = node.Tag as String;

            if (tag.Contains("Driver:") || tag.Contains("Dir:"))
            {
                tag = tag.Substring(tag.IndexOf(":") + 1);
                DirInfo dirInfo = new DirInfo(tag, false);

                dirInfo.ShowIn(node);
            }
        }

        # endregion

    }


    public class PicTool
    {
        public static void SaveToFile(Image pic)
        {
            String path = System.AppDomain.CurrentDomain.BaseDirectory + "screen";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            string fileName = path + "\\" + DateTime.Now.ToString("yyyy-MM-dd_HH.mm.ss.fff") + ".jpg";

            SaveToFile(pic, fileName, true, null);
        }

        //保存图像pic到文件fileName中，指定图像保存格式
        public static void SaveToFile(Image pic, string fileName, bool replace, ImageFormat format)    //ImageFormat.Jpeg
        {
            //若图像已存在，则删除
            if (System.IO.File.Exists(fileName) && replace)
                System.IO.File.Delete(fileName);

            //若不存在则创建
            if (!System.IO.File.Exists(fileName))
            {
                if (format == null) format = getFormat(fileName);   //根据拓展名获取图像的对应存储类型

                if (format == ImageFormat.MemoryBmp) pic.Save(fileName);
                else pic.Save(fileName, format);                    //按给定格式保存图像
            }
        }

        //根据文件拓展名，获取对应的存储类型
        public static ImageFormat getFormat(string filePath)
        {
            ImageFormat format = ImageFormat.MemoryBmp;
            String Ext = System.IO.Path.GetExtension(filePath).ToLower();

            if (Ext.Equals(".png")) format = ImageFormat.Png;
            else if (Ext.Equals(".jpg") || Ext.Equals(".jpeg")) format = ImageFormat.Jpeg;
            else if (Ext.Equals(".bmp")) format = ImageFormat.Bmp;
            else if (Ext.Equals(".gif")) format = ImageFormat.Gif;
            else if (Ext.Equals(".ico")) format = ImageFormat.Icon;
            else if (Ext.Equals(".emf")) format = ImageFormat.Emf;
            else if (Ext.Equals(".exif")) format = ImageFormat.Exif;
            else if (Ext.Equals(".tiff")) format = ImageFormat.Tiff;
            else if (Ext.Equals(".wmf")) format = ImageFormat.Wmf;
            else if (Ext.Equals(".memorybmp")) format = ImageFormat.MemoryBmp;

            return format;
        }
    }


    /// <summary>
    /// 获取屏幕截图
    /// </summary>
    public class ScreenTool
    {
        [DllImport("user32.dll")]
        static extern bool GetCursorInfo(out CURSORINFO pci);

        private const Int32 CURSOR_SHOWING = 0x00000001;
        [StructLayout(LayoutKind.Sequential)]
        struct POINT
        {
            public Int32 x;
            public Int32 y;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct CURSORINFO
        {
            public Int32 cbSize;
            public Int32 flags;
            public IntPtr hCursor;
            public POINT ptScreenPos;
        }

        /// <summary>
        /// 截取屏幕指定区域为Image，保存到路径savePath下，haveCursor是否包含鼠标
        /// </summary>
        public static Image getScreen(int x = 0, int y = 0, int width = -1, int height = -1, String savePath = "", bool haveCursor = true)
        {
            if (width == -1) width = SystemInformation.VirtualScreen.Width;
            if (height == -1) height = SystemInformation.VirtualScreen.Height;

            Bitmap tmp = new Bitmap(width, height);                 //按指定大小创建位图
            Graphics g = Graphics.FromImage(tmp);                   //从位图创建Graphics对象
            g.CopyFromScreen(x, y, 0, 0, new Size(width, height));  //绘制

            // 绘制鼠标
            if (haveCursor)
            {
                try
                {
                    CURSORINFO pci;
                    pci.cbSize = Marshal.SizeOf(typeof(CURSORINFO));
                    GetCursorInfo(out pci);
                    System.Windows.Forms.Cursor cur = new System.Windows.Forms.Cursor(pci.hCursor);
                    cur.Draw(g, new Rectangle(pci.ptScreenPos.x, pci.ptScreenPos.y, cur.Size.Width, cur.Size.Height));
                }
                catch (Exception ex) { }    // 若获取鼠标异常则不显示
            }

            //Size halfSize = new Size((int)(tmp.Size.Width * 0.8), (int)(tmp.Size.Height * 0.8));  // 按一半尺寸存储图像
            //if (!savePath.Equals("")) saveImage(tmp, tmp.Size, savePath);       // 保存到指定的路径下

            return tmp;     //返回构建的新图像
        }

        /// <summary>
        /// 获取屏幕截图，转化为数据串
        /// </summary>
        public static String getScreenData()
        {
            Image pic = getScreen();
            String data = RecodeTool.Image2String(pic);
            return data;
        }
    }

    //public class IconData
    //{
    //    public Icon icon;

    //    public IconData(Icon icon)
    //    {
    //        this.icon = icon;
    //    }

    //    public static void Test(Form form)
    //    {
    //        Icon icon = SystemIcon.Get(3);
    //        Bitmap bitmap = icon.ToBitmap();
    //        byte[] data = RecodeTool.Image2Bytes(bitmap);
    //        String Str = RecodeTool.Bytes2String(data);

    //        byte[] data2 = RecodeTool.String2Bytes(Str);
    //        Image pic = RecodeTool.Bytes2Image(data2);

    //        IntPtr ptr = ((Bitmap)pic).GetHicon();
    //        Icon icon2 = Icon.FromHandle(ptr);

    //        form.Icon = icon2;
    //    }

    //    //将当前对象的数据，转化为Json串
    //    public String ToJson()
    //    {
    //        return JsonConvert.SerializeObject(this);
    //    }

    //    //从Json串创建对象  
    //    public static IconData Parse(string JsonStr)
    //    {
    //        return JsonConvert.DeserializeObject<IconData>(JsonStr);
    //    }
    //}

}

