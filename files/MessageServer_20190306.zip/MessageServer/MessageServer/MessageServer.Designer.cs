﻿namespace MessageServer
{
    partial class MessageServer
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_Port = new System.Windows.Forms.TextBox();
            this.textBox_Ip = new System.Windows.Forms.TextBox();
            this.button_start = new System.Windows.Forms.Button();
            this.textBox_send = new System.Windows.Forms.TextBox();
            this.button_send = new System.Windows.Forms.Button();
            this.comboBox_clients = new System.Windows.Forms.ComboBox();
            this.label_clientIp = new System.Windows.Forms.Label();
            this.textBox_showing = new System.Windows.Forms.RichTextBox();
            this.linkLabel_Echo = new System.Windows.Forms.LinkLabel();
            this.checkBox_isCmd = new System.Windows.Forms.CheckBox();
            this.panel_msg = new System.Windows.Forms.Panel();
            this.panel_func = new System.Windows.Forms.Panel();
            this.linkLabel_closeServer = new System.Windows.Forms.LinkLabel();
            this.linkLabel_desktop = new System.Windows.Forms.LinkLabel();
            this.linkLabel_Explorer = new System.Windows.Forms.LinkLabel();
            this.panel_msg.SuspendLayout();
            this.panel_func.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox_Port
            // 
            this.textBox_Port.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_Port.Location = new System.Drawing.Point(243, 3);
            this.textBox_Port.Name = "textBox_Port";
            this.textBox_Port.Size = new System.Drawing.Size(49, 21);
            this.textBox_Port.TabIndex = 19;
            this.textBox_Port.Text = "37280";
            // 
            // textBox_Ip
            // 
            this.textBox_Ip.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_Ip.Location = new System.Drawing.Point(84, 3);
            this.textBox_Ip.Name = "textBox_Ip";
            this.textBox_Ip.Size = new System.Drawing.Size(153, 21);
            this.textBox_Ip.TabIndex = 18;
            this.textBox_Ip.Text = "127.0.0.1";
            // 
            // button_start
            // 
            this.button_start.Location = new System.Drawing.Point(3, 3);
            this.button_start.Name = "button_start";
            this.button_start.Size = new System.Drawing.Size(75, 23);
            this.button_start.TabIndex = 17;
            this.button_start.Text = "启动服务";
            this.button_start.UseVisualStyleBackColor = true;
            this.button_start.Click += new System.EventHandler(this.button_start_Click);
            // 
            // textBox_send
            // 
            this.textBox_send.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_send.Location = new System.Drawing.Point(5, 29);
            this.textBox_send.Multiline = true;
            this.textBox_send.Name = "textBox_send";
            this.textBox_send.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox_send.Size = new System.Drawing.Size(282, 37);
            this.textBox_send.TabIndex = 16;
            // 
            // button_send
            // 
            this.button_send.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_send.Location = new System.Drawing.Point(212, 68);
            this.button_send.Name = "button_send";
            this.button_send.Size = new System.Drawing.Size(75, 23);
            this.button_send.TabIndex = 15;
            this.button_send.Text = "发送信息";
            this.button_send.UseVisualStyleBackColor = true;
            this.button_send.Click += new System.EventHandler(this.button_send_Click);
            // 
            // comboBox_clients
            // 
            this.comboBox_clients.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_clients.FormattingEnabled = true;
            this.comboBox_clients.Location = new System.Drawing.Point(74, 5);
            this.comboBox_clients.Name = "comboBox_clients";
            this.comboBox_clients.Size = new System.Drawing.Size(213, 20);
            this.comboBox_clients.TabIndex = 20;
            this.comboBox_clients.DropDown += new System.EventHandler(this.comboBox_clients_DropDown);
            // 
            // label_clientIp
            // 
            this.label_clientIp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label_clientIp.AutoSize = true;
            this.label_clientIp.Location = new System.Drawing.Point(3, 8);
            this.label_clientIp.Name = "label_clientIp";
            this.label_clientIp.Size = new System.Drawing.Size(65, 12);
            this.label_clientIp.TabIndex = 21;
            this.label_clientIp.Text = "选择客户端";
            // 
            // textBox_showing
            // 
            this.textBox_showing.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_showing.Location = new System.Drawing.Point(3, 27);
            this.textBox_showing.Name = "textBox_showing";
            this.textBox_showing.Size = new System.Drawing.Size(289, 201);
            this.textBox_showing.TabIndex = 22;
            this.textBox_showing.Text = "";
            // 
            // linkLabel_Echo
            // 
            this.linkLabel_Echo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.linkLabel_Echo.AutoSize = true;
            this.linkLabel_Echo.Location = new System.Drawing.Point(81, 4);
            this.linkLabel_Echo.Name = "linkLabel_Echo";
            this.linkLabel_Echo.Size = new System.Drawing.Size(65, 12);
            this.linkLabel_Echo.TabIndex = 23;
            this.linkLabel_Echo.TabStop = true;
            this.linkLabel_Echo.Text = "客户端输出";
            this.linkLabel_Echo.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_Echo_LinkClicked);
            // 
            // checkBox_isCmd
            // 
            this.checkBox_isCmd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBox_isCmd.AutoSize = true;
            this.checkBox_isCmd.Location = new System.Drawing.Point(108, 72);
            this.checkBox_isCmd.Name = "checkBox_isCmd";
            this.checkBox_isCmd.Size = new System.Drawing.Size(102, 16);
            this.checkBox_isCmd.TabIndex = 25;
            this.checkBox_isCmd.Text = "以cmd格式发送";
            this.checkBox_isCmd.UseVisualStyleBackColor = true;
            // 
            // panel_msg
            // 
            this.panel_msg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_msg.Controls.Add(this.checkBox_isCmd);
            this.panel_msg.Controls.Add(this.comboBox_clients);
            this.panel_msg.Controls.Add(this.textBox_send);
            this.panel_msg.Controls.Add(this.label_clientIp);
            this.panel_msg.Controls.Add(this.button_send);
            this.panel_msg.Location = new System.Drawing.Point(3, 231);
            this.panel_msg.Name = "panel_msg";
            this.panel_msg.Size = new System.Drawing.Size(290, 94);
            this.panel_msg.TabIndex = 26;
            // 
            // panel_func
            // 
            this.panel_func.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_func.Controls.Add(this.linkLabel_desktop);
            this.panel_func.Controls.Add(this.linkLabel_Explorer);
            this.panel_func.Controls.Add(this.linkLabel_closeServer);
            this.panel_func.Controls.Add(this.linkLabel_Echo);
            this.panel_func.Location = new System.Drawing.Point(3, 328);
            this.panel_func.Name = "panel_func";
            this.panel_func.Size = new System.Drawing.Size(290, 21);
            this.panel_func.TabIndex = 27;
            // 
            // linkLabel_closeServer
            // 
            this.linkLabel_closeServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.linkLabel_closeServer.AutoSize = true;
            this.linkLabel_closeServer.Location = new System.Drawing.Point(3, 4);
            this.linkLabel_closeServer.Name = "linkLabel_closeServer";
            this.linkLabel_closeServer.Size = new System.Drawing.Size(65, 12);
            this.linkLabel_closeServer.TabIndex = 25;
            this.linkLabel_closeServer.TabStop = true;
            this.linkLabel_closeServer.Text = "关闭客户端";
            this.linkLabel_closeServer.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_closeServer_LinkClicked);
            // 
            // linkLabel_desktop
            // 
            this.linkLabel_desktop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLabel_desktop.AutoSize = true;
            this.linkLabel_desktop.Location = new System.Drawing.Point(159, 4);
            this.linkLabel_desktop.Name = "linkLabel_desktop";
            this.linkLabel_desktop.Size = new System.Drawing.Size(53, 12);
            this.linkLabel_desktop.TabIndex = 27;
            this.linkLabel_desktop.TabStop = true;
            this.linkLabel_desktop.Text = "查看桌面";
            this.linkLabel_desktop.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_desktop_LinkClicked);
            // 
            // linkLabel_Explorer
            // 
            this.linkLabel_Explorer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLabel_Explorer.AutoSize = true;
            this.linkLabel_Explorer.Location = new System.Drawing.Point(225, 4);
            this.linkLabel_Explorer.Name = "linkLabel_Explorer";
            this.linkLabel_Explorer.Size = new System.Drawing.Size(53, 12);
            this.linkLabel_Explorer.TabIndex = 26;
            this.linkLabel_Explorer.TabStop = true;
            this.linkLabel_Explorer.Text = "文件浏览";
            this.linkLabel_Explorer.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_Explorer_LinkClicked);
            // 
            // MessageServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(295, 349);
            this.Controls.Add(this.panel_func);
            this.Controls.Add(this.panel_msg);
            this.Controls.Add(this.textBox_showing);
            this.Controls.Add(this.textBox_Port);
            this.Controls.Add(this.textBox_Ip);
            this.Controls.Add(this.button_start);
            this.Name = "MessageServer";
            this.ShowInTaskbar = false;
            this.Text = "服务器";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MessageServer_FormClosed);
            this.panel_msg.ResumeLayout(false);
            this.panel_msg.PerformLayout();
            this.panel_func.ResumeLayout(false);
            this.panel_func.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_Port;
        private System.Windows.Forms.TextBox textBox_Ip;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.TextBox textBox_send;
        private System.Windows.Forms.Button button_send;
        private System.Windows.Forms.ComboBox comboBox_clients;
        private System.Windows.Forms.Label label_clientIp;
        private System.Windows.Forms.RichTextBox textBox_showing;
        private System.Windows.Forms.LinkLabel linkLabel_Echo;
        private System.Windows.Forms.CheckBox checkBox_isCmd;
        private System.Windows.Forms.Panel panel_msg;
        private System.Windows.Forms.Panel panel_func;
        private System.Windows.Forms.LinkLabel linkLabel_desktop;
        private System.Windows.Forms.LinkLabel linkLabel_Explorer;
        private System.Windows.Forms.LinkLabel linkLabel_closeServer;

    }
}

