﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MessageClient
{
    public partial class ScreenForm : Form
    {
        ClientAdapter adapter;

        public bool isRemoteMode = false;
        public ScreenForm(Object clientObj = null)
        {
            InitializeComponent();

            if (clientObj != null)
            {
                isRemoteMode = true;
                adapter = (clientObj as Client).Adapter();
            }
        }

        /// <summary>
        /// 获取client端截屏
        /// </summary>
        public Image GetScreen()
        {
            String data = adapter.GetScreen();
            Image screen = RecodeTool.String2Image(data);
            return screen;
        }

        /// <summary>
        /// 刷新界面显示
        /// </summary>
        private void showScreen()
        {
            Image image = GetScreen();
            pictureBox_screen.Image = image;

            if(checkBox_save.Checked) PicTool.SaveToFile(image);
        }

        private void timer_refresh_Tick(object sender, EventArgs e)
        {
            showScreen();
        }

        private void button_refresh_Click(object sender, EventArgs e)
        {
            showScreen();
        }

        /// <summary>
        /// 自动刷新
        /// </summary>
        private void checkBox_auto_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox_auto.Checked)
            {
                timer_refresh.Interval = Int32.Parse(textBox_interval.Text.Trim());
                timer_refresh.Enabled = true;
            }
            else timer_refresh.Enabled = false;
        }

    }
}
