﻿namespace MessageServer
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Sockets;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;
    using System.Linq;

    public class Server
    {
        public string ipString = "127.0.0.1";   // 服务器端ip
        public int port = 37280;                // 服务器端口
        
        public Socket socket;
        public Print print;                     // 运行时的信息输出方法

        public Dictionary<string, Socket> clients = new Dictionary<string, Socket>();   // 存储连接到服务器的客户端信息
        public bool started = false;            // 标识当前是否启动了服务

        public Print dataPrint;                 // 数据接收方法
        

        private long preTimetick = 0;
        public List<string> getClientList(string clientIp = "")
        {
            // 5s内仅刷新获取一次客户端信息
            long currentTimeTick = new DateTime().Ticks / 10000000;
            if (preTimetick == 0) preTimetick = currentTimeTick - 5;
            if (currentTimeTick - preTimetick >= 5)
            {
                preTimetick = currentTimeTick;

                List<string> keys = clients.Keys.ToList<string>();
                foreach (String key in keys)
                {
                    if (key.Equals(clientIp)) continue;
                    Send("check Connet", key);
                }
            }

            return clients.Keys.ToList<string>();
        }

        /// <summary>
        /// 获取已连接的所有客户端信息
        /// </summary>
        public string ConnectedClients(string clientIp)
        {
            getClientList(clientIp);

            StringBuilder builder = new StringBuilder();
            List<string> keys = clients.Keys.ToList<string>();
            foreach (String key in keys)
            {
                if (clientIp.Equals(key)) continue;
                builder.Append(key + ";");
            }
            string data = builder.ToString();
            if(data.EndsWith(";")) data = data.Substring(0, data.Length-1);
            return data;
        }

        public Server(Print print = null, string ipString = null, int port = -1)
        {
            this.print = print;
            if (ipString != null) this.ipString = ipString;
            if (port >= 0)this.port = port;
        }

        public Server(Print print = null, string ipString = null, string port = "-1")
        {
            this.print = print;
            if (ipString != null) this.ipString = ipString;

            int port_int = Int32.Parse(port);
            if (port_int >= 0) this.port = port_int;
        }

        /// <summary>
        /// 设置数据接收函数
        /// </summary>
        public void setDataPrint(Print print)
        {
            this.dataPrint = print;
        }


        /// <summary>
        /// Print用于输出Server的输出信息
        /// </summary>
        public delegate void Print(string info);

        /// <summary>
        /// 启动服务
        /// </summary>
        public void start()
        {
            try
            {
                IPAddress address = IPAddress.Parse(ipString);
                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                socket.Bind(new IPEndPoint(address, port));   
                socket.Listen(10000);

                if (print != null)
                {
                    try { print("启动服务【" + socket.LocalEndPoint.ToString() + "】成功"); }
                    catch { print = null; }
                }
                started = true;

                new Thread(listenClientConnect).Start(socket);  // 在新的线程中监听客户端连接
            }
            catch (Exception exception)
            {
                if (print != null)
                {
                    print("启动服务失败 " + exception.ToString());
                }
                started = false;
            }
        }

        /// <summary>
        /// 监听客户端的连接
        /// </summary>
        private void listenClientConnect(object obj)
        {
            Socket socket = (Socket) obj;
            while (true)
            {
                Socket clientScoket = socket.Accept();
                if (print != null)
                {
                    print("客户端" + clientScoket.RemoteEndPoint.ToString() + "已连接");
                }
                new Thread(receiveData).Start(clientScoket);   // 在新的线程中接收客户端信息

                Thread.Sleep(1000);                            // 延时1秒后，接收连接请求
                if (!started) return;
            }
        }

        private string selectClientId = "";
        /// <summary>
        /// 设置待发送的客户端信息
        /// </summary>
        public void SetClientId(string id)
        {
            selectClientId = id;
        }

         /// <summary>
        /// 发送信息
        /// </summary>
        public void Send(string info)
        {
            Send(info, selectClientId);
        }

        /// <summary>
        /// 发送信息
        /// </summary>
        private void Send(string info, string id)
        {
            if (clients.ContainsKey(id))
            {
                Socket socket = clients[id];

                try 
                { 
                    Send(socket, info); 
                }
                catch(Exception ex)
                {
                    clients.Remove(id);
                    if (print != null) print("客户端已断开，【" + id + "】");
                }
            }
        }

        /// <summary>
        /// 通过socket发送数据data
        /// </summary>
        private void Send(Socket socket, string data)
        {
            if (socket != null && data != null && !data.Equals(""))
            {
                byte[] bytes = Encoding.UTF8.GetBytes(data);   // 将data转化为byte数组
                socket.Send(bytes);                            // 
            }
        }

        private string clientIp = "";
        /// <summary>
        /// 输出Server的输出信息到客户端
        /// </summary>
        public void PrintOnClient(string info)
        {
            Send(info, clientIp);
        }

        /// <summary>
        /// 接收通过socket发送过来的数据
        /// </summary>
        private void receiveData(object obj)
        {
            Socket socket = (Socket) obj;

            string clientIp = socket.RemoteEndPoint.ToString();                 // 获取客户端标识 ip和端口
            if (!clients.ContainsKey(clientIp)) clients.Add(clientIp, socket);  // 将连接的客户端socket添加到clients中保存
            else clients[clientIp] = socket;

            while (true)
            {
                try
                {
                    string str = Receive(socket);
                    if (!str.Equals(""))
                    {
                        if (str.StartsWith("[.Transfer]")) TranferTo(clientIp, str);  // 转发数据
                        else
                        {
                            if (str.Equals("[.Shutdown]")) Environment.Exit(0);      // 服务器退出
                            else if (str.StartsWith("[.RunCmd]")) runCMD(str);            // 执行cmd命令
                            else if (str.Equals("[.Echo]"))
                            {
                                this.clientIp = clientIp;
                                print = new Print(PrintOnClient);     // 在客户端显示服务器输出信息

                                print("【" + clientIp + "】" + str);
                            }
                            else if (str.StartsWith("[data]->"))
                            {
                                if (dataPrint != null) dataPrint(str);
                            }
                            else if (str.StartsWith("[.FileInfo]"))    // 本地文件目录信息
                            {
                                string data = LocalFile.Process(str, this, clientIp); // 获取本地文件信息
                                if (!data.Equals(""))
                                {
                                    Print tmpPrint = print;           // 记录输出方法
                                    print = new Print(PrintOnClient);

                                    string tmpIp = this.clientIp;     // 记录客户端ip
                                    this.clientIp = clientIp;

                                    print(data);                      // 返回文件信息
                                    //print("[dataEnd]");               // 返回数据结束信息
                                    //"[data]->"

                                    this.clientIp = tmpIp;
                                    print = tmpPrint;
                                }
                            }
                            else if (print != null) print("【" + clientIp + "】" + str);
                        }
                    }
                }
                catch (Exception exception)
                {
                    if (print != null) print("连接已自动断开，【" + clientIp + "】" + exception.Message);

                    socket.Shutdown(SocketShutdown.Both);
                    socket.Close();

                    if (clients.ContainsKey(clientIp)) clients.Remove(clientIp);
                    return;
                }

                if (!started) return;
                Thread.Sleep(20);      // 延时0.02秒后再接收客户端发送的消息
            }
        }

        /// <summary>
        /// 对clientIp发送来的数据进行转发
        /// </summary>
        private void TranferTo(string srcClientIp, string cmd)
        {
            string START = "[.Transfer]";
            cmd = cmd.Substring(START.Length).Trim();       // 获取cmd信息
            string[] A = LocalFile.SplitTwo(cmd, "[.:]");

            string destClientIp = A[0];
            string data = A[1];

            if (destClientIp.Equals(srcClientIp)) return;

            if (data.Equals("[.SetTransfer]")) data += srcClientIp;
            TranData(destClientIp, data);   // 转发数据
        }

        /// <summary>
        /// 转发数据data到destClientIp
        /// </summary>
        private void TranData(string destClientIp, string data)
        {
            string tmpIp = this.clientIp;    // 记录客户端ip
            this.clientIp = destClientIp ;

            PrintOnClient(data);             // 返回文件信息

            this.clientIp = tmpIp;
        }

        /// <summary>
        /// 执行cmd命令
        /// </summary>
        private void runCMD(string cmd)
        {
            new Thread(runCMD_0).Start(cmd);
        }

        /// <summary>
        /// 执行cmd命令
        /// </summary>
        private void runCMD_0(object obj)
        {
            string cmd = (string)obj;
            string START = "[.RunCmd]";
            if (cmd.StartsWith(START))
            {
                cmd = cmd.Substring(START.Length);  // 获取cmd信息
                Cmd.Run(cmd, print);                // 执行cmd，输出执行结果到print
            }
        }

        private string preReceive = "";
        /// <summary>
        /// 从socket接收数据,对于较大数据，需要多次接收数据
        /// </summary>
        private string Receive(Socket socket)
        {
            Boolean isFileInfo = false;
            string data = preReceive + ReceiveProcess(socket);
            preReceive = "";

            string START = "[.Transfer]";
            string HeadAppend = "";
            if (data.StartsWith(START))
            {
                string[] A = LocalFile.SplitTwo(data, "[.:]");
                HeadAppend = A[0] + "[.:]";
                data = A[1];
            }

            if (data.StartsWith("[.FileInfo]"))
            {
                isFileInfo = true;
                while (isFileInfo)
                {
                    data += ReceiveProcess(socket);
                    if (data.Contains("[.FileInfoEnd]"))
                    {
                        int index = data.IndexOf("[.FileInfoEnd]");
                        preReceive = data.Substring(index + "[.FileInfoEnd]".Length);   // 获取前一次接收剩余未处理的数据

                        data = data.Substring(0, index);
                        if (!HeadAppend.Equals("")) data += "[.FileInfoEnd]";
                        break;
                    }
                }
            }
            else if (data.StartsWith("[data]->"))
            {
                isFileInfo = true;
                while (isFileInfo)
                {
                    data += ReceiveProcess(socket);
                    if (data.Contains("[dataEnd]"))
                    {
                        int index = data.IndexOf("[dataEnd]");
                        preReceive = data.Substring(index + "[dataEnd]".Length);   // 获取前一次接收剩余未处理的数据

                        data = data.Substring(0, index);
                        if (!HeadAppend.Equals("")) data += "[dataEnd]";
                        break;
                    }
                }
            }

            return HeadAppend + data;
        }

        /// <summary>
        /// 从socket接收数据,对于较大数据，需要多次接收数据
        /// </summary>
        private string ReceiveProcess(Socket socket)
        {
            StringBuilder data = new StringBuilder();
            int len = 0;

            do
            {
                byte[] bytes = null;
                len = socket.Available;

                if (len > 0)
                {
                    bytes = new byte[len];
                    int receiveNumber = socket.Receive(bytes);
                    data.Append(Encoding.UTF8.GetString(bytes, 0, receiveNumber));
                }

            } while (len == 8192);  // 达到最大长度

            return data.ToString();
        }

        /// <summary>
        /// 停止服务
        /// </summary>
        public void stop()
        {
            started = false;
        }
    }
}
