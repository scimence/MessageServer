﻿namespace MessageClient
{
    partial class MessageClient
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button_connect = new System.Windows.Forms.Button();
            this.textBox_send = new System.Windows.Forms.TextBox();
            this.button_send = new System.Windows.Forms.Button();
            this.textBox_Ip = new System.Windows.Forms.TextBox();
            this.textBox_Port = new System.Windows.Forms.TextBox();
            this.linkLabel_closeServer = new System.Windows.Forms.LinkLabel();
            this.checkBox_isCmd = new System.Windows.Forms.CheckBox();
            this.textBox_showing = new System.Windows.Forms.RichTextBox();
            this.linkLabel_Echo = new System.Windows.Forms.LinkLabel();
            this.linkLabel_Explorer = new System.Windows.Forms.LinkLabel();
            this.linkLabel_desktop = new System.Windows.Forms.LinkLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboBox_clients = new System.Windows.Forms.ComboBox();
            this.label_clientIp = new System.Windows.Forms.Label();
            this.label_refresh = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_connect
            // 
            this.button_connect.Location = new System.Drawing.Point(3, 7);
            this.button_connect.Name = "button_connect";
            this.button_connect.Size = new System.Drawing.Size(75, 23);
            this.button_connect.TabIndex = 11;
            this.button_connect.Text = "连接服务器";
            this.button_connect.UseVisualStyleBackColor = true;
            this.button_connect.Click += new System.EventHandler(this.button_connect_Click);
            // 
            // textBox_send
            // 
            this.textBox_send.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_send.Location = new System.Drawing.Point(5, 28);
            this.textBox_send.Multiline = true;
            this.textBox_send.Name = "textBox_send";
            this.textBox_send.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox_send.Size = new System.Drawing.Size(280, 37);
            this.textBox_send.TabIndex = 10;
            // 
            // button_send
            // 
            this.button_send.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_send.Location = new System.Drawing.Point(207, 64);
            this.button_send.Name = "button_send";
            this.button_send.Size = new System.Drawing.Size(75, 23);
            this.button_send.TabIndex = 9;
            this.button_send.Text = "发送信息";
            this.button_send.UseVisualStyleBackColor = true;
            this.button_send.Click += new System.EventHandler(this.button_send_Click);
            // 
            // textBox_Ip
            // 
            this.textBox_Ip.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_Ip.Location = new System.Drawing.Point(84, 7);
            this.textBox_Ip.Name = "textBox_Ip";
            this.textBox_Ip.Size = new System.Drawing.Size(153, 21);
            this.textBox_Ip.TabIndex = 12;
            this.textBox_Ip.Text = "127.0.0.1";
            // 
            // textBox_Port
            // 
            this.textBox_Port.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_Port.Location = new System.Drawing.Point(243, 7);
            this.textBox_Port.Name = "textBox_Port";
            this.textBox_Port.Size = new System.Drawing.Size(49, 21);
            this.textBox_Port.TabIndex = 13;
            this.textBox_Port.Text = "37280";
            // 
            // linkLabel_closeServer
            // 
            this.linkLabel_closeServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.linkLabel_closeServer.AutoSize = true;
            this.linkLabel_closeServer.Location = new System.Drawing.Point(5, 5);
            this.linkLabel_closeServer.Name = "linkLabel_closeServer";
            this.linkLabel_closeServer.Size = new System.Drawing.Size(65, 12);
            this.linkLabel_closeServer.TabIndex = 14;
            this.linkLabel_closeServer.TabStop = true;
            this.linkLabel_closeServer.Text = "关闭服务器";
            this.linkLabel_closeServer.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_closeServer_LinkClicked);
            // 
            // checkBox_isCmd
            // 
            this.checkBox_isCmd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBox_isCmd.AutoSize = true;
            this.checkBox_isCmd.Location = new System.Drawing.Point(94, 71);
            this.checkBox_isCmd.Name = "checkBox_isCmd";
            this.checkBox_isCmd.Size = new System.Drawing.Size(102, 16);
            this.checkBox_isCmd.TabIndex = 15;
            this.checkBox_isCmd.Text = "以cmd格式发送";
            this.checkBox_isCmd.UseVisualStyleBackColor = true;
            // 
            // textBox_showing
            // 
            this.textBox_showing.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_showing.Location = new System.Drawing.Point(4, 31);
            this.textBox_showing.Name = "textBox_showing";
            this.textBox_showing.Size = new System.Drawing.Size(287, 202);
            this.textBox_showing.TabIndex = 16;
            this.textBox_showing.Text = "";
            // 
            // linkLabel_Echo
            // 
            this.linkLabel_Echo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.linkLabel_Echo.AutoSize = true;
            this.linkLabel_Echo.Location = new System.Drawing.Point(81, 5);
            this.linkLabel_Echo.Name = "linkLabel_Echo";
            this.linkLabel_Echo.Size = new System.Drawing.Size(65, 12);
            this.linkLabel_Echo.TabIndex = 17;
            this.linkLabel_Echo.TabStop = true;
            this.linkLabel_Echo.Text = "服务器输出";
            this.linkLabel_Echo.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_Echo_LinkClicked);
            // 
            // linkLabel_Explorer
            // 
            this.linkLabel_Explorer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLabel_Explorer.AutoSize = true;
            this.linkLabel_Explorer.Location = new System.Drawing.Point(226, 5);
            this.linkLabel_Explorer.Name = "linkLabel_Explorer";
            this.linkLabel_Explorer.Size = new System.Drawing.Size(53, 12);
            this.linkLabel_Explorer.TabIndex = 18;
            this.linkLabel_Explorer.TabStop = true;
            this.linkLabel_Explorer.Text = "文件浏览";
            this.linkLabel_Explorer.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_Explorer_LinkClicked);
            // 
            // linkLabel_desktop
            // 
            this.linkLabel_desktop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLabel_desktop.AutoSize = true;
            this.linkLabel_desktop.Location = new System.Drawing.Point(162, 5);
            this.linkLabel_desktop.Name = "linkLabel_desktop";
            this.linkLabel_desktop.Size = new System.Drawing.Size(53, 12);
            this.linkLabel_desktop.TabIndex = 19;
            this.linkLabel_desktop.TabStop = true;
            this.linkLabel_desktop.Text = "查看桌面";
            this.linkLabel_desktop.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_desktop_LinkClicked);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.linkLabel_desktop);
            this.panel1.Controls.Add(this.linkLabel_Explorer);
            this.panel1.Controls.Add(this.linkLabel_Echo);
            this.panel1.Controls.Add(this.linkLabel_closeServer);
            this.panel1.Location = new System.Drawing.Point(3, 328);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(287, 22);
            this.panel1.TabIndex = 20;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.label_refresh);
            this.panel2.Controls.Add(this.comboBox_clients);
            this.panel2.Controls.Add(this.label_clientIp);
            this.panel2.Controls.Add(this.checkBox_isCmd);
            this.panel2.Controls.Add(this.textBox_send);
            this.panel2.Controls.Add(this.button_send);
            this.panel2.Location = new System.Drawing.Point(3, 235);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(286, 89);
            this.panel2.TabIndex = 21;
            // 
            // comboBox_clients
            // 
            this.comboBox_clients.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_clients.FormattingEnabled = true;
            this.comboBox_clients.Location = new System.Drawing.Point(76, 4);
            this.comboBox_clients.Name = "comboBox_clients";
            this.comboBox_clients.Size = new System.Drawing.Size(171, 20);
            this.comboBox_clients.TabIndex = 22;
            this.comboBox_clients.SelectedIndexChanged += new System.EventHandler(this.comboBox_clients_SelectedIndexChanged);
            // 
            // label_clientIp
            // 
            this.label_clientIp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label_clientIp.AutoSize = true;
            this.label_clientIp.Location = new System.Drawing.Point(5, 7);
            this.label_clientIp.Name = "label_clientIp";
            this.label_clientIp.Size = new System.Drawing.Size(65, 12);
            this.label_clientIp.TabIndex = 23;
            this.label_clientIp.Text = "选择客户端";
            // 
            // label_refresh
            // 
            this.label_refresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_refresh.AutoSize = true;
            this.label_refresh.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_refresh.ForeColor = System.Drawing.Color.Blue;
            this.label_refresh.Location = new System.Drawing.Point(253, 7);
            this.label_refresh.Name = "label_refresh";
            this.label_refresh.Size = new System.Drawing.Size(29, 12);
            this.label_refresh.TabIndex = 24;
            this.label_refresh.Text = "刷新";
            this.label_refresh.Click += new System.EventHandler(this.label_refresh_Click);
            // 
            // MessageClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(295, 354);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBox_showing);
            this.Controls.Add(this.textBox_Port);
            this.Controls.Add(this.textBox_Ip);
            this.Controls.Add(this.button_connect);
            this.Name = "MessageClient";
            this.Text = "客户端";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MessageClient_FormClosed);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_connect;
        private System.Windows.Forms.TextBox textBox_send;
        private System.Windows.Forms.Button button_send;
        private System.Windows.Forms.TextBox textBox_Ip;
        private System.Windows.Forms.TextBox textBox_Port;
        private System.Windows.Forms.LinkLabel linkLabel_closeServer;
        private System.Windows.Forms.CheckBox checkBox_isCmd;
        private System.Windows.Forms.RichTextBox textBox_showing;
        private System.Windows.Forms.LinkLabel linkLabel_Echo;
        private System.Windows.Forms.LinkLabel linkLabel_Explorer;
        private System.Windows.Forms.LinkLabel linkLabel_desktop;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox comboBox_clients;
        private System.Windows.Forms.Label label_clientIp;
        private System.Windows.Forms.Label label_refresh;
    }
}

