﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MessageClient
{
    public partial class MessageClient : Form
    {
        Client client;    // 客户端实例

        public MessageClient()
        {
            InitializeComponent();
        }

        // 连接服务器
        private void button_connect_Click(object sender, EventArgs e)
        {
            if (client != null && client.connected) client.stop();  // 

            if (client == null) client = new Client(ClientPrint, textBox_Ip.Text, textBox_Port.Text);
            if (!client.connected) client.start();
            if (client != null) this.Text = "客户端 " + client.localIpPort;

            label_refresh_Click(null, null);
        }

        // 客户端输出信息
        private void ClientPrint(string info)
        {
            if (textBox_showing.InvokeRequired)
            {
                Client.Print F = new Client.Print(ClientPrint);
                this.Invoke(F, new object[] { info });
            }
            else
            {
                if (info != null)
                {
                    textBox_showing.SelectionColor = Color.Green;
                    textBox_showing.AppendText(info);
                    if(!info.StartsWith(Environment.NewLine) && !info.EndsWith(Environment.NewLine)) 
                        textBox_showing.AppendText(Environment.NewLine);
                    textBox_showing.ScrollToCaret();
                }
            }
        }

        // 发送信息到服务器
        private void button_send_Click(object sender, EventArgs e)
        {
            if (client != null && client.connected)
            {
                string info = textBox_send.Text;
                if (checkBox_isCmd.Checked && !info.StartsWith("[.RunCmd]"))    // 添加cmd串头信息
                    info = "[.RunCmd]" + info;

                client.Send(info);
            }
        }

        // 关闭界面停止服务运行
        private void MessageClient_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (client != null && client.connected)
                client.stop();
        }

        private void linkLabel_closeServer_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (client != null && client.connected)
                client.Send("[.Shutdown]");
        }

        private void linkLabel_Echo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (client != null && client.connected)
                client.Send("[.Echo]");
        }

        private void linkLabel_desktop_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (client != null && client.connected)
            {
                //new ExplorerForm().Show();
                new ScreenForm(client).Show();
            }
        }

        private void linkLabel_Explorer_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //new FileExplorer.ExplorerForm().Show();
            if (client != null && client.connected)
            {
                //new ExplorerForm().Show();
                new ExplorerForm(client).Show();
            }
        }

        private void comboBox_clients_DropDown(object sender, EventArgs e)
        {
            
        }

        /// <summary>
        /// 获取服务器端客户端列表信息
        /// </summary>
        private void label_refresh_Click(object sender, EventArgs e)
        {
            if (client != null && client.connected)
            {
                string clientId = comboBox_clients.Text.Trim();
                List<string> clients = client.Adapter().GetServerClients();

                comboBox_clients.DataSource = clients;
                if (clients.Contains(clientId)) comboBox_clients.Text = clientId;
                else if (clients.Count > 0) comboBox_clients.Text = clients[0];
            }
        }

        string remoteId = "";
        private void comboBox_clients_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 数据转发格式
            string str = comboBox_clients.Text.Trim();
            if (!remoteId.Equals(str))
            {
                remoteId = str;
                client.SetTransfer(remoteId);

                if(!remoteId.Equals("[服务器端]") && !remoteId.Equals(""))
                    client.Send("[.SetTransfer]"); // 通知客户端连接
            }
        }
    }
}
