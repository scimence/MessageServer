﻿using FileExplorer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MessageServer
{
    /// <summary>
    /// 本地文件信息获取、处理类
    /// </summary>
    class LocalFile
    {
        public static string Process(string cmd)
        {
            string data = "";

            try
            {
                string START = "[.FileInfo]";
                if (cmd.StartsWith(START))
                {
                    cmd = cmd.Substring(START.Length).Trim();   // 获取cmd信息

                    if (cmd.Equals("[.DriverInfo]"))            // 磁盘信息
                    {
                        data = (new DriverInfo()).ToJson();
                    }
                    else if (cmd.Equals("[.SystemDirTree]"))    // 目录树信息
                    {
                        data = (new SystemDirTree()).ToJson();
                    }
                    else if (cmd.StartsWith("[.DirInfo]"))
                    {
                        string path = cmd.Substring("[.DirInfo]".Length).Trim();  // 路径
                        data = (new DirInfo(path)).ToJson();    // 指定目录文件信息
                    }
                }
            }
            catch (Exception ex)
            {
            }

            if (data.Equals("")) return "";
            else return "[data]->" + data;
        }
    }

}
